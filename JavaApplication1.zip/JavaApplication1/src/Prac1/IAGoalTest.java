package Prac1;

import aima.search.framework.GoalTest;

public class IAGoalTest implements GoalTest {

    public boolean isGoalState(Object state){

        return false;
    }
}